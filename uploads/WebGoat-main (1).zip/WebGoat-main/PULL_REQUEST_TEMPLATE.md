Thank you for submitting a pull request to the WebGoat!
